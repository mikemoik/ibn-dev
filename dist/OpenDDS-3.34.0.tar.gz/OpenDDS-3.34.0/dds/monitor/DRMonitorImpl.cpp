/*
 *
 *
 * Distributed under the OpenDDS License.
 * See: http://www.opendds.org/license.html
 */

#include "DRMonitorImpl.h"
#include "monitorC.h"
#include "monitorTypeSupportImpl.h"
#include "dds/DCPS/DataReaderImpl.h"
#include <dds/DdsDcpsInfrastructureC.h>

OPENDDS_BEGIN_VERSIONED_NAMESPACE_DECL

namespace OpenDDS {
namespace Monitor {


DRMonitorImpl::DRMonitorImpl(DCPS::DataReaderImpl* dr,
                             DataReaderReportDataWriter_ptr dr_writer)
  : dr_(dr)
  , dr_writer_(DataReaderReportDataWriter::_duplicate(dr_writer))
{
}

DRMonitorImpl::~DRMonitorImpl()
{
}

void
DRMonitorImpl::report() {
  if (!CORBA::is_nil(dr_writer_.in())) {
    DataReaderReport report;
    report.dp_id = dr_->get_dp_id();
    DDS::Subscriber_var sub = dr_->get_subscriber();
    report.sub_handle = sub->get_instance_handle();
    report.dr_id = dr_->get_guid();
    report.topic_id = dr_->get_topic_id();
    DCPS::DataReaderImpl::InstanceHandleVec instances;
    dr_->get_instance_handles(instances);
    CORBA::ULong length = 0;
    report.instances.length(static_cast<CORBA::ULong>(instances.size()));
    for (DCPS::DataReaderImpl::InstanceHandleVec::iterator iter = instances.begin();
         iter != instances.end();
         ++iter) {
      report.instances[length++] = *iter;
    }
    DCPS::DataReaderImpl::WriterStatePairVec writer_states;
    dr_->get_writer_states(writer_states);
    length = 0;
    report.associations.length(static_cast<CORBA::ULong>(writer_states.size()));
    for (DCPS::DataReaderImpl::WriterStatePairVec::iterator iter = writer_states.begin();
         iter != writer_states.end();
         ++iter) {
      report.associations[length].dw_id = iter->first;
      report.associations[length].state = static_cast<CORBA::Short>(iter->second);
      length++;
    }
    dr_writer_->write(report, DDS::HANDLE_NIL);
  }
}

}
}

OPENDDS_END_VERSIONED_NAMESPACE_DECL
