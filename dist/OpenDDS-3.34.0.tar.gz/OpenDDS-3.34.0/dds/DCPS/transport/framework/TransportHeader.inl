/*
 *
 *
 * Distributed under the OpenDDS License.
 * See: http://www.opendds.org/license.html
 */

#include "dds/DCPS/Serializer.h"
#include "EntryExit.h"

#include <algorithm>

OPENDDS_BEGIN_VERSIONED_NAMESPACE_DECL

namespace OpenDDS {
namespace DCPS {

ACE_INLINE
TransportHeader::TransportHeader()
  : byte_order_(ACE_CDR_BYTE_ORDER)
  , first_fragment_(false)
  , last_fragment_(false)
  , reserved_(0)
  , length_(0)
  , sequence_()
  , source_(0)
{
  DBG_ENTRY_LVL("TransportHeader","TransportHeader",6);

  std::copy(&DCPS_PROTOCOL[0], &DCPS_PROTOCOL[6], this->protocol_);
}

ACE_INLINE
TransportHeader::TransportHeader(ACE_Message_Block& buffer)
  : byte_order_(ACE_CDR_BYTE_ORDER)
  , first_fragment_(false)
  , last_fragment_(false)
  , reserved_(0)
  , length_(0)
  , sequence_()
  , source_(0)
{
  DBG_ENTRY_LVL("TransportHeader","TransportHeader",6);
  this->init(&buffer);
}

ACE_INLINE
TransportHeader&
TransportHeader::operator=(ACE_Message_Block& buffer)
{
  DBG_ENTRY_LVL("TransportHeader","operator=",6);
  this->init(&buffer);
  return *this;
}

ACE_INLINE
size_t TransportHeader::get_max_serialized_size()
{
  // Representation takes no extra space for encoding.
  const TransportHeader* hdr = 0;
  return sizeof(hdr->protocol_) +
         1 /*flags*/ +
         sizeof(hdr->reserved_) +
         sizeof(hdr->length_) +
         sizeof(hdr->sequence_) +
         sizeof(hdr->source_);
}

ACE_INLINE
bool
TransportHeader::swap_bytes() const
{
  DBG_ENTRY_LVL("TransportHeader","swap_bytes",6);

  return this->byte_order_ != ACE_CDR_BYTE_ORDER;
}

ACE_INLINE
bool
TransportHeader::valid() const
{
  DBG_ENTRY_LVL("TransportHeader","valid",6);

  // Currently we do not support compatibility with other
  // versions of the protocol:
  return std::equal(&DCPS_PROTOCOL[0], &DCPS_PROTOCOL[6], this->protocol_);
}

ACE_INLINE
bool
TransportHeader::init(ACE_Message_Block* buffer)
{
  DBG_ENTRY_LVL("TransportHeader","init",6);

  Serializer reader(buffer, Encoding::KIND_UNALIGNED_CDR);

  if (!reader.read_octet_array(this->protocol_, sizeof(this->protocol_)))
    return false;

  ACE_CDR::Octet flags;
  if (!(reader >> ACE_InputCDR::to_octet(flags)))
    return false;

  this->byte_order_ = flags & (1 << TH_BYTE_ORDER_FLAG);
  this->first_fragment_ = flags & (1 << FIRST_FRAGMENT_FLAG);
  this->last_fragment_ = flags & (1 << LAST_FRAGMENT_FLAG);

  if (!(reader >> ACE_InputCDR::to_octet(this->reserved_)))
    return false;

  reader.swap_bytes(swap_bytes());

  return (reader >> this->length_) &&
         (reader >> this->sequence_) &&
         (reader >> this->source_);
}

}
}

OPENDDS_END_VERSIONED_NAMESPACE_DECL
